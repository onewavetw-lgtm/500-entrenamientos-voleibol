import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Check, X, Zap, Smartphone, ShieldCheck, Clock, CheckCircle2, Star, ChevronDown, Target, ListTodo, BookOpen, Gift } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

// Assets
import heroMockup from "@/assets/images/hero-mockup.png";
import planBasico from "@/assets/images/plan-basico.png";
import plantillaMaster from "@/assets/images/plantilla-master.png";
import arsenalPremium from "@/assets/images/arsenal-premium.png";
import manualTactico from "@/assets/images/manual-tactico.png";
import fundamentosImg from "@/assets/images/fundamentos.png";
import recepcionImg from "@/assets/images/recepcion.png";
import coachCarlos from "@/assets/images/coach-carlos.webp";
import coachMartin from "@/assets/images/coach-martin.webp";
import coachAndrea from "@/assets/images/coach-andrea.webp";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "+500 Entrenamientos de Voleibol" },
      { name: "description", content: "+500 exercícios e planos prontos para treinadores de voleibol." },
    ],
  }),
  component: SalesPage,
});

function SalesPage() {
  const [timeLeft, setTimeLeft] = useState(14 * 60 + 37);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    // UTMify Pixel
    (window as any).pixelId = "6a28af0a84fac4cd8ac5c773";
    const a = document.createElement("script");
    a.setAttribute("async", "");
    a.setAttribute("defer", "");
    a.setAttribute("src", "https://cdn.utmify.com.br/scripts/pixel/pixel.js");
    document.head.appendChild(a);

    // UTMify UTM tracking
    const s = document.createElement("script");
    s.src = "https://cdn.utmify.com.br/scripts/utms/latest.js";
    s.async = true;
    s.defer = true;
    s.setAttribute("data-utmify-prevent-subids", "");
    document.head.appendChild(s);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return { mins: mins.toString().padStart(2, '0'), secs: secs.toString().padStart(2, '0') };
  };

  const { mins, secs } = formatTime(timeLeft);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 scroll-smooth">
      {/* 1. HERO SECTION */}
      <section className="relative pt-16 pb-20 md:pt-32 md:pb-32 bg-slate-950 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-blue-600 opacity-20 blur-[120px] rounded-full pointer-events-none"></div>
        <div className="absolute top-1/2 left-0 -translate-x-1/2 w-[400px] h-[400px] bg-orange-500 opacity-10 blur-[100px] rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          <div className="fade-in">
            <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-300 px-4 py-2 rounded-full text-sm font-semibold mb-8 backdrop-blur-sm mx-auto">
              <Zap className="w-4 h-4 text-orange-400" />
              <span>Material Digital para Entrenadores</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-extrabold text-white tracking-tight mb-6 md:mb-8 leading-[1.1] max-w-5xl mx-auto px-2">
              ¿Cansado de buscar ejercicios en internet? Ten tu clase lista <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-orange-400">antes de pisar la cancha</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-8 md:mb-10 leading-relaxed font-light px-2">
              Pasa de la frustración de no saber qué enseñar hoy, a tener una estructura clara con <strong className="text-white font-bold">+500 ejercicios y planes</strong> listos para aplicar con cualquier nivel.
            </p>
          </div>

          {/* Mockup */}
          <div className="fade-in mt-8 mb-12 mx-auto max-w-4xl relative">
            <img src={heroMockup} alt="Mockup +500 Entrenamientos de Voleibol" className="w-full h-auto object-contain drop-shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
          </div>

          <div className="fade-in">
            <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-12">
              {[
                { icon: Zap, text: "Acceso inmediato" },
                { icon: Smartphone, text: "Funciona en celular" },
                { icon: ShieldCheck, text: "Pago único" },
                { icon: ShieldCheck, text: "Garantía de 7 días" },
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-2 text-slate-300 text-sm md:text-base font-medium">
                  <item.icon className="w-[18px] h-[18px] text-blue-400 shrink-0" />
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="fade-in max-w-md mx-auto">
            <a href="#oferta" className="w-full font-bold py-4 px-8 rounded-full shadow-[0_4px_14px_0_rgba(22,163,74,0.39)] hover:shadow-[0_6px_20px_rgba(22,163,74,0.23)] hover:-translate-y-1 transition-all duration-300 flex justify-center items-center bg-green-600 hover:bg-green-700 text-white text-xl">
              QUIERO ACCEDER AHORA
            </a>
            <p className="text-slate-400 text-sm mt-4 font-medium flex justify-center items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> Material digital. Recibe el acceso después de la compra.
            </p>
          </div>

          <div className="fade-in mt-16 text-center max-w-2xl mx-auto">
            <div className="relative p-6 md:p-8 rounded-3xl bg-slate-900/50 backdrop-blur border border-slate-700/50 text-white shadow-xl overflow-hidden text-center">
              <p className="text-lg md:text-xl font-medium relative z-10 leading-relaxed">
                "No es una carpeta desordenada de PDFs. Es una base práctica para crear entrenamientos que dan resultados."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* EXAMPLES CAROUSEL */}
      <section className="py-16 md:py-24 bg-slate-50 overflow-hidden border-b border-slate-100">
        <div className="w-full mx-auto px-0 max-w-[100vw]">
          <div className="text-center mb-12 px-4">
            <div className="fade-in">
              <h2 className="text-3xl md:text-5xl font-extrabold mb-4 text-slate-900">
                Mira uno de los materiales que <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-400">recibirás en la práctica</span>
              </h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">Desliza para ver una vista previa del conteúdo que tendrás en tus manos.</p>
            </div>
          </div>
          
          <div className="fade-in">
            <div className="w-full relative py-8 overflow-hidden">
              <div className="carousel-track flex w-max">
                <div className="flex gap-4 md:gap-6 pr-4 md:pr-6">
                  {[fundamentosImg, recepcionImg, fundamentosImg, recepcionImg].map((img, i) => (
                    <div key={i} className="w-[240px] md:w-[280px] lg:w-[320px] aspect-[1/1.414] shrink-0 rounded-xl overflow-hidden shadow-lg border border-slate-200 relative flex bg-white transition-transform duration-300 hover:-translate-y-1">
                      <img src={img} alt={`Exemplo ${i}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
                <div className="flex gap-4 md:gap-6 pr-4 md:pr-6">
                  {[fundamentosImg, recepcionImg, fundamentosImg, recepcionImg].map((img, i) => (
                    <div key={i+4} className="w-[240px] md:w-[280px] lg:w-[320px] aspect-[1/1.414] shrink-0 rounded-xl overflow-hidden shadow-lg border border-slate-200 relative flex bg-white transition-transform duration-300 hover:-translate-y-1">
                      <img src={img} alt={`Exemplo ${i+4}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. DELIVERABLES */}
      <section className="py-16 md:py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16 fade-in">
            <h2 className="text-base text-blue-600 font-bold tracking-wide uppercase mb-2">Contenido Exclusivo</h2>
            <h3 className="text-3xl md:text-5xl font-extrabold text-slate-900 mb-6">¿Qué vas a recibir?</h3>
            <p className="text-lg text-slate-600">Todo organizado para preparar clases y entrenamientos con más rapidez, variedad y seguridad.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Target, title: "Ejercicios por Fundamento", desc: "Actividades para principiantes, antebrazo, voleo, recepción, saque bajo, defensa, bloqueo y remate." },
              { icon: ListTodo, title: "Planes de Entrenamiento", desc: "Modelos prácticos para organizar sesiones con más orden, progresión y claridad." },
              { icon: BookOpen, title: "Manuales para Entrenadores", desc: "Material de apoyo para ampliar tu repertorio y preparar mejores clases." },
              { icon: Zap, title: "Voleibol de Playa", desc: "Ejercicios extra para adaptar dinámicas y variar tus entrenamientos." }
            ].map((item, i) => (
              <div key={i} className="fade-in h-full">
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-8 h-full hover:shadow-xl transition-all hover:-translate-y-2 group cursor-pointer">
                  <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <item.icon className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-3 leading-tight">{item.title}</h4>
                  <p className="text-slate-600 leading-relaxed font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="fade-in mt-16 text-center">
            <p className="inline-block bg-blue-50 text-blue-800 px-6 py-3 rounded-full font-semibold border border-blue-100 shadow-sm text-sm sm:text-base">
              Una base práctica para consultar, elegir el ejercicio adequado y aplicar directamente en cancha.
            </p>
          </div>
        </div>
      </section>

      {/* 3. BENEFITS */}
      <section className="py-16 md:py-24 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900">¿Por qué elegir este material?</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10 max-w-5xl mx-auto">
            {[
              { title: "Menos improvisación", desc: "Llega a la cancha con una idea clara." },
              { title: "Más variedad", desc: "Deja de repetir siempre las mismas atividades." },
              { title: "Ahorro de tiempo", desc: "Reduce horas buscando ejercicios en internet." },
              { title: "Más organización", desc: "Prepara sesiones con objetivo y estrutura." },
              { title: "Aplicación inmediata", desc: "Consulta el material y úsalo en cancha." },
              { title: "Más seguridad", desc: "Transmite más profesionalismo como entrenador." }
            ].map((item, i) => (
              <div key={i} className="fade-in flex gap-4">
                <div className="mt-1">
                  <div className="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center shrink-0">
                    <Check className="w-[18px] h-[18px]" />
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-slate-900 mb-1">{item.title}</h4>
                  <p className="text-slate-600 font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. BONUSES */}
      <section className="py-16 md:py-24 bg-blue-900 relative overflow-hidden text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="text-center mb-16 fade-in">
            <span className="bg-orange-500 text-white text-sm font-bold uppercase tracking-wider px-4 py-1.5 rounded-full mb-4 inline-block">Sorpresa Especial</span>
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mt-4">Recibe 3 bonos especiales</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              { id: '01', img: plantillaMaster, title: "Plantilla Máster: Planificador Semanal de Sesiones", desc: "Estructura tus semanas de entrenamiento en minutos asegurando una progresión clara para tus equipos. (Valorado en US$ 19,90)" },
              { id: '02', img: arsenalPremium, title: "Arsenal Premium: Banco de Variantes Técnicas", desc: "Más de 50 adaptaciones y variantes de ejercicios para romper la monotonía y desafiar a tus jogadores. (Valorado en US$ 25,00)" },
              { id: '03', img: manualTactico, title: "Manual Táctico: El Entrenador de Alto Impacto", desc: "El paso a paso exacto para comunicarte mejor, corregir errores rápidamente y liderar tu equipo. (Valorado en US$ 15,00)" }
            ].map((item, i) => (
              <div key={i} className="fade-in h-full">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 h-full relative overflow-hidden group hover:bg-white/15 transition-all flex flex-col items-center">
                  <div className="absolute -right-4 -top-6 text-7xl font-black text-white/5 group-hover:text-white/10 transition-colors select-none">{item.id}</div>
                  <div className="h-40 flex items-center justify-center mb-6 relative z-10 w-full">
                    <img src={item.img} alt={item.title} className="max-h-full max-w-full object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-300" />
                  </div>
                  <h4 className="text-xl font-bold text-white mb-3 relative z-10 uppercase tracking-tight">{item.title}</h4>
                  <p className="text-blue-200 relative z-10 font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="fade-in mt-12 text-center">
            <p className="text-orange-300 font-bold text-lg">Bonos incluidos gratis en el Plan Completo.</p>
          </div>
        </div>
      </section>

      {/* 5. PRICING (OFERTA) */}
      <section id="oferta" className="py-12 md:py-24 bg-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <div className="fade-in">
              <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">Elige tu acceso</h2>
            </div>
            <div className="fade-in">
              <div className="inline-flex flex-col sm:flex-row bg-red-50 text-red-600 font-bold px-4 py-3 sm:py-2 rounded-2xl sm:rounded-full mb-6 border border-red-100 shadow-sm uppercase tracking-wider text-xs sm:text-sm items-center justify-center gap-2 max-w-fit mx-auto">
                <Clock className="w-4 h-4 shrink-0" />
                <span>Esta oferta especial es válida únicamente por hoy. El acceso expira en: {mins}:{secs}</span>
              </div>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mt-12 items-center">
            {/* PLAN BÁSICO */}
            <div className="fade-in h-full">
              <div className="bg-white rounded-3xl p-8 lg:p-10 border border-slate-200 shadow-lg h-full flex flex-col md:scale-95 origin-right relative">
                <div className="mb-8 text-center">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Plan Básico</h3>
                  <p className="text-slate-500 font-medium">Para quien quiere acceder solo al material principal.</p>
                </div>
                <div className="mb-8 flex flex-col justify-center items-center w-full">
                  <img src={planBasico} alt="Plan Básico" className="h-40 w-auto object-contain drop-shadow-xl hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="mb-8 flex items-baseline justify-center">
                  <span className="text-5xl font-black text-green-600 tracking-tighter">US$ 5,00</span>
                </div>
                <p className="text-sm font-semibold text-slate-500 uppercase tracking-widest mb-8 bg-slate-100 py-2 px-4 rounded-lg inline-block self-center">Pago único. Acceso inmediato.</p>

                <div className="space-y-4 mb-10 flex-grow">
                  {[
                    { text: "+500 Entrenamientos de Voleibol", included: true },
                    { text: "Ejercicios listos para aplicar", included: true },
                    { text: "Acceso inmediato", included: true },
                    { text: "Funciona en celular", included: true },
                    { text: "Manuales para entrenadores", included: false },
                    { text: "Planes de entrenamiento", included: false },
                    { text: "Voleibol de playa", included: false },
                    { text: "Bonos especiales", included: false }
                  ].map((item, i) => (
                    <div key={i} className={`flex items-start gap-3 ${!item.included ? 'opacity-50' : ''}`}>
                      {item.included ? <Check className="w-5 h-5 text-green-500 shrink-0" /> : <X className="w-5 h-5 text-slate-400 shrink-0" />}
                      <span className={`font-medium ${item.included ? 'text-slate-700' : 'text-slate-500 line-through decoration-slate-300'}`}>{item.text}</span>
                    </div>
                  ))}
                </div>

                <div className="flex justify-center">
                  <a href="https://pay.hotmart.com/T106239854U?checkoutMode=10&utm_source=organic&utm_campaign=&utm_medium=&utm_content=&utm_term=" className="w-auto bg-green-100 hover:bg-green-200 text-green-800 font-bold py-4 px-12 rounded-xl transition-colors duration-300">
                    ELEGIR BÁSICO
                  </a>

                </div>
              </div>
            </div>

            {/* PLAN COMPLETO */}
            <div className="fade-in h-full relative z-10">
              <div className="bg-slate-900 text-white rounded-3xl p-8 lg:p-10 border-4 border-orange-500 shadow-[0_20px_50px_rgba(249,115,22,0.15)] h-full flex flex-col relative transform hover:-translate-y-2 transition-transform duration-500">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-orange-400 to-orange-600 text-white uppercase tracking-widest font-bold text-sm py-2 px-6 rounded-full shadow-lg">
                  MÁS VENDIDO
                </div>
                <div className="mb-6 mt-4 text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Plan Completo</h3>
                  <p className="text-slate-400 font-medium">La opción ideal para entrenadores que quieren todo el material y los bonos.</p>
                </div>
                <div className="mb-8 flex flex-col justify-center items-center w-full">
                  <img src={heroMockup} alt="Plan Completo" className="h-44 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="mb-6 text-center">
                  <span className="text-red-400 line-through text-xl font-bold block mb-1">De US$ 47</span>
                  <div className="flex items-baseline justify-center">
                    <span className="text-6xl font-black text-green-400 tracking-tighter">US$ 7,90</span>
                  </div>
                </div>
                <p className="text-sm font-semibold text-blue-200 uppercase tracking-widest mb-8 bg-blue-900/50 py-2 px-4 rounded-lg inline-block self-center border border-blue-800/50">Pago único. Sin mensualidades.</p>

                <div className="space-y-4 mb-10 flex-grow">
                  {[
                    "+500 Entrenamientos de Voleibol",
                    "Ejercicios por fundamento",
                    "Planes de entrenamiento",
                    "Manual para entrenadores",
                    "Manual para entrenadores Nivel II",
                    "Manual de voleibol de playa",
                    "Planificador de sesiones (Bono)",
                    "Banco extra de exercícios (Bono)",
                    "Guía rápida del entrenador (Bono)",
                    "Acceso inmediato & Funciona en celular",
                    "Garantía de 7 días"
                  ].map((text, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-orange-400 shrink-0" />
                      <span className="text-slate-200 font-medium">{text}</span>
                    </div>
                  ))}
                </div>

                <div className="flex flex-col items-center">
                  <a href="https://pay.hotmart.com/Q106240017W?checkoutMode=10&bid=1781049060638&utm_source=organic&utm_campaign=&utm_medium=&utm_content=&utm_term=" className="w-auto bg-gradient-to-r from-green-500 to-green-600 hover:from-green-400 hover:to-green-500 text-white font-black py-5 px-10 rounded-xl shadow-lg hover:shadow-green-500/25 transition-all duration-300 text-lg uppercase tracking-wide">
                    QUIERO EL COMPLETO
                  </a>

                  <div className="flex justify-center items-center gap-2 mt-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    <ShieldCheck className="w-3.5 h-3.5" /> Compra segura. Garantía 7 días.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIALS */}
      <section className="py-16 md:py-24 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900">Lo que dicen otros entrenadores</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[
              { name: "Carlos Alberto Méndez", loc: "Monterrey, México - Profesor", text: "Antes perdía horas buscando videos sueltos en YouTube para mis clases de iniciación. Ahora, reviso mi celular 10 minutos antes de la clase e já tengo una progresión lógica." },
              { name: "Andrea López Suárez", loc: "Bogotá, Colombia - Entrenadora", text: "Me frustraba chegar a la cancha y sentir que repetía las mismas dinámicas. Esta base de datos me dio la seguridad que necesitaba. Es sumamente práctico." },
              { name: "Martín E. Rodríguez", loc: "Córdoba, Argentina - Coach", text: "La planificación me tomaba muchísimo tiempo que no tenía. Desde que uso estos manuales, estructuro mi semana en minutos. O cambio en la organización se nota." }
            ].map((t, i) => (
              <div key={i} className="fade-in h-full">
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 h-full flex flex-col relative text-center">
                  <div className="flex gap-1 text-orange-400 mb-6 justify-center">
                    {[1,2,3,4,5].map(s => <Star key={s} className="w-[18px] h-[18px] fill-current" />)}
                  </div>
                  <p className="text-slate-700 italic mb-8 flex-grow text-lg font-medium leading-relaxed">"{t.text}"</p>
                  <div className="flex flex-col items-center gap-4 mt-auto">
                    <div className="w-14 h-14 rounded-full bg-blue-600 flex items-center justify-center text-white text-xl font-bold border-2 border-slate-100 shrink-0 uppercase">
                      {t.name.split(' ').slice(0, 3).map(n => n[0]).join('')}
                    </div>


                    <div>
                      <p className="font-bold text-slate-900 leading-tight">{t.name}</p>
                      <p className="text-sm text-slate-500 font-semibold">{t.loc}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. GUARANTEE */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-blue-600 to-blue-800 text-white relative overflow-hidden text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="fade-in">
            <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner backdrop-blur-md">
              <ShieldCheck className="w-10 h-10 text-orange-400" />
            </div>
            <h2 className="text-3xl md:text-5xl font-extrabold mb-6 tracking-tight">Garantía incondicional de 7 días</h2>
            <p className="text-lg md:text-xl text-blue-100 max-w-3xl mx-auto mb-10 leading-relaxed font-medium">
              Prueba el material completo durante 7 días. Si sientes que no te ajuda a preparar tus clases o entrenamientos de voleibol, puedes solicitar la devolución y recibir el <strong className="text-white">100% de tu dinero</strong>.
            </p>
            <p className="bg-white/10 inline-block px-6 py-3 rounded-full font-bold tracking-wide uppercase text-orange-300 border border-white/20">
              Tú no asumes ningún riesgo.
            </p>
          </div>
        </div>
      </section>

      {/* 8. FAQ */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900">Preguntas frecuentes</h2>
          </div>
          
          <div className="fade-in max-w-3xl mx-auto space-y-4">
            <Accordion type="single" collapsible className="w-full space-y-4">
              {[
                { q: "¿Cómo recibo el acceso?", a: "Después de la compra, recibirás las instrucciones por correo electrónico. El acceso es inmediato." },
                { q: "¿El pago es mensual?", a: "No. Es un pago único. No hay mensualidades." },
                { q: "¿Es seguro pagar por internet?", a: "Totalmente seguro. Utilizamos una plataforma de pagos internacional con encriptación SSL y protección de los datos de tu tarjeta." },
                { q: "¿Puedo acceder desde el celular?", a: "Sí. Puedes acceder desde celular, tablet o computadora." },
                { q: "¿Qué incluye el Plan Básico?", a: "El Plan Básico incluye el material principal: +500 Entrenamientos de Voleibol, con acceso inmediato y pago único." },
                { q: "¿Qué incluye el Plan Completo?", a: "El Plan Completo incluye el material principal, ejercicios por fundamento, planes de entrenamiento, manuales para entrenadores, voleibol de playa, 3 bonos especiales y garantía de 7 días." }
              ].map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-sm hover:shadow-md transition-shadow px-6">
                  <AccordionTrigger className="text-lg font-semibold text-slate-800 hover:no-underline py-5">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-slate-600 leading-relaxed pb-6">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>

          <div className="fade-in mt-16 text-center">
            <a href="#oferta" className="w-full md:w-auto font-bold py-4 px-8 rounded-full shadow-[0_4px_14px_0_rgba(34,197,94,0.2)] hover:shadow-[0_6px_20px_rgba(34,197,94,0.3)] hover:-translate-y-1 transition-all duration-300 text-lg flex justify-center items-center bg-green-100 hover:bg-green-200 text-green-900 inline-block">
              QUIERO ACCEDER AHORA
            </a>
          </div>
        </div>
      </section>

      {/* 9. FOOTER */}
      <footer className="bg-slate-950 py-12 border-t border-slate-900 text-center text-white/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-slate-500 font-semibold mb-6 flex justify-center gap-4 flex-wrap text-sm uppercase tracking-wider">
            <a href="#" className="hover:text-slate-300 transition-colors">Términos de uso</a>
            <span>|</span>
            <a href="#" className="hover:text-slate-300 transition-colors">Privacidad</a>
            <span>|</span>
            <a href="#" className="hover:text-slate-300 transition-colors">Soporte</a>
          </div>
          <p className="text-slate-600 text-sm mb-4">
            Observación: Material digital educativo para entrenadores, profesores e instructores de voleibol.
          </p>
          <p className="text-slate-700 font-medium text-xs uppercase tracking-widest">
            © 2026 +500 Entrenamientos. Todos los direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}
